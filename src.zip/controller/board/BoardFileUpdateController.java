package controller.board;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import dao.board.BoardDao;
import dao.board.BoardDaoImpl;
import dto.UploadFile;

@WebServlet("/board/fileupdate")
public class BoardFileUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String b_no = request.getParameter("b_no");
		request.setAttribute("b_no", b_no);
		request.getRequestDispatcher("/view/board/fileupdatetab.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		ServletContext context = getServletContext();
		
		//파일업로드 설정 정보
		String saveDirectory = context.getRealPath("/cos/upload");
		int maxPostSize = 10 * 1024 * 1024;
		String encoding = "UTF-8";	
		FileRenamePolicy policy = new DefaultFileRenamePolicy();
		
		//파일업로드
		MultipartRequest mul = new MultipartRequest(
				req,
				saveDirectory,
				maxPostSize,
				encoding,
				policy );
		
		BoardDao dao = new BoardDaoImpl(); 
		
		String bno = req.getParameter("b_no");
		int b_no = Integer.parseInt(bno);
		
		//파일번호얻기
		int fileno = dao.getFileno(); 
		
		//파일 정보
		UploadFile file = new UploadFile();
		file.setFileno(fileno);
		file.setOrigin_name(mul.getOriginalFileName("upfile"));
		file.setStored_name(mul.getFilesystemName("upfile"));
		file.setContent_ype(mul.getContentType("upfile"));
		file.setFile_size(mul.getFile("upfile").length());
		//파일삽입
		dao.UpdateFile(b_no, file);

		//파일정보를 부모창에 전달하며 팝업닫기
		resp.setCharacterEncoding("UTF-8");
		resp.getWriter().print("<html><head><meta charset=\"UTF-8\"></head><script type='text/javascript'>window.onload = function() {opener.sendData("+file.getFileno()+",'"+file.getOrigin_name()+"');  window.close();}</script></html>");
	}
}
