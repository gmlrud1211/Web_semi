package controller.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.Board;
import service.board.BoardService;
import service.board.BoardServiceImpl;

@WebServlet("/board/write")
public class BoardWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BoardService boardService = new BoardServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 요청파라미터 -> u_name 
		/*
		 * String user = userService.getUserName(request); System.out.println(user);
		 * request.setAttribute("userName", user);
		 */

		//로그인 되어있지 않으면 /main으로 리다이렉트
		/*
			if( request.getSession().getAttribute("login") == null ) {
			//로그인해야 이용이 가능하다는 처리 추가해야함!
			response.sendRedirect("/main"); //리다이렉트
			return; //doGet 중단
		}
		*/
		request.getRequestDispatcher("/view/board/write.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		// file_no 
		// u_no
		// 추가해야함!!
		
		Board board = new Board();
		
		String b_head = request.getParameter("head");
		String b_title = request.getParameter("title");
		String b_content = request.getParameter("content");
		String fileno = request.getParameter("fileno");
		int file_no = Integer.parseInt(fileno);
		
		
		board.setB_head(b_head);
		board.setB_title(b_title);
		board.setB_content(b_content);
		board.setFile_no(file_no);
		
		int b_no = boardService.getBoardno();
		
		boardService.updateFileBNo(b_no, file_no);
		boardService.boardWrite(b_no, board);
		
		response.sendRedirect("/board/list");
		
	}
}
